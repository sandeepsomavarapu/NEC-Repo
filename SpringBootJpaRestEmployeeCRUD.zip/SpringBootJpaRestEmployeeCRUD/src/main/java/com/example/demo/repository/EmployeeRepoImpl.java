package com.example.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Employee;

@Repository
public class EmployeeRepoImpl implements EmployeeRepo {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addEmployee(Employee employee) {
		entityManager.persist(employee);
		return "Employee Inserted Successfully";
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		return entityManager.merge(employee);
	}

	@Override
	public String deleteEmployee(int employeeId) {
		entityManager.remove(getEmployee(employeeId));
		return "Employee Removed ...";
	}

	@Override
	public Employee getEmployee(int employeeId) {

		return entityManager.find(Employee.class, employeeId);
	}

	@Override
	public List<Employee> getAllEmployees() {
		TypedQuery<Employee> result = entityManager.createQuery("select e from Employee e", Employee.class);
		return result.getResultList();

	}

	@Override
	public List<Employee> getEmployeesInBetweenSalary(int intialSal, int finalSal) {
		TypedQuery<Employee> result = entityManager
				.createQuery("select e from Employee e where e.empSalary between ?1 and ?2", Employee.class);
		result.setParameter(1, intialSal);
		result.setParameter(2, finalSal);
		return result.getResultList();
	}

	@Override
	public List<Employee> getEmployeesByName(String employeeName) {
		TypedQuery<Employee> result = entityManager.createQuery("select e from Employee e where e.empName=?1",
				Employee.class);
		result.setParameter(1, employeeName);
		return result.getResultList();
	}

	@Override
	public List<Employee> getEmployeesByDesg(String employeeDesg) {
		TypedQuery<Employee> result = entityManager.createQuery("select e from Employee e where e.empDesg=?1",
				Employee.class);
		result.setParameter(1, employeeDesg);
		return result.getResultList();
	}

}
