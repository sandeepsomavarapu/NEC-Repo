package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepo;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepo repo;

	@Override
	public String addEmployee(Employee employee) {

		return repo.addEmployee(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		return repo.updateEmployee(employee);
	}

	@Override
	public String deleteEmployee(int employeeId) {

		return repo.deleteEmployee(employeeId);
	}

	@Override
	public Employee getEmployee(int employeeId) {

		return repo.getEmployee(employeeId);
	}

	@Override
	public List<Employee> getAllEmployees() {

		return repo.getAllEmployees();
	}

	@Override
	public List<Employee> getEmployeesInBetweenSalary(int intialSal, int finalSal) {

		return repo.getEmployeesInBetweenSalary(intialSal, finalSal);
	}

	@Override
	public List<Employee> getEmployeesByName(String employeeName) {
		return repo.getEmployeesByName(employeeName);
	}

	@Override
	public List<Employee> getEmployeesByDesg(String employeeDesg) {
		return repo.getEmployeesByDesg(employeeDesg);
	}

}
