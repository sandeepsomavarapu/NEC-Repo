package com.example.demo.repository;

import java.util.List;

import com.example.demo.model.Employee;

public interface EmployeeRepo {

	String addEmployee(Employee employee);

	Employee updateEmployee(Employee employee);

	String deleteEmployee(int employeeId);

	Employee getEmployee(int employeeId);

	List<Employee> getAllEmployees();

	List<Employee> getEmployeesInBetweenSalary(int intialSal, int finalSal);

	List<Employee> getEmployeesByName(String employeeName);

	List<Employee> getEmployeesByDesg(String employeeDesg);

}
