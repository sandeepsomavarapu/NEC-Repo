package com.pdw.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("1-1BI");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();

		Student student = new Student();
		student.setName("akash");

		Address homeAddress = new Address();
		homeAddress.setStreet("narayanpet");
		homeAddress.setCity("mnagar");
		homeAddress.setState("telangana");
		homeAddress.setZipCode("500074");
		 homeAddress.setStudent(student);
		// inject address into student
		//student.setAddress(homeAddress);
		
		// persist only student, no need to persist Address explicitly
		em.persist(homeAddress);
		
//		Address add=em.find(Address.class,2);
//		em.remove(add);
		em.getTransaction().commit();
//		System.out.println("removed one student with address to database.");
		em.close();
		factory.close();
	}
}
