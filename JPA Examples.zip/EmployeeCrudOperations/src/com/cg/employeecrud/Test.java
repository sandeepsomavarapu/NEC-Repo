package com.cg.employeecrud;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("sleeping");

		EntityManager entity = factory.createEntityManager();

		entity.getTransaction().begin();

//				Employee emp=new Employee(123,"suresh",50000,"hyd");//ORM
//				entity.persist(emp);//save insert,update,delete

		Employee emp = entity.find(Employee.class, 123);
		//	emp.setEmpName("akash");
		// entity.merge(emp);
			
			entity.remove(emp);
			
			
		entity.getTransaction().commit();
		entity.close();
		factory.close();

	}

}
