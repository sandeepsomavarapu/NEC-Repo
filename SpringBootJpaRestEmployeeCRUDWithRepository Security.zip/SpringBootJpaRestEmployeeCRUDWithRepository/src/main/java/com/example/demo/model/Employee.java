package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "necemps")
public class Employee {
	@Id
	@Column(name="eid")
	private int empId;
	@Column(name="ename",length = 15)
	@NotNull(message = "Please provide employee name")
    @Pattern(regexp="[A-Za-z]+( [A-Za-z]+)*", message="Name should contain only alphabets and space")
	private String empName;
	@Column(length=15)
	@NotNull(message = "Please provide employee desgination")
	@NotBlank(message="Invalid Designation ")
	private String empDesg;
	@Min(message = "pass mininimum salary as 10000 ", value =10000)
	private int empSalary;
	@Email(message = "Please provide valid email address")
    @NotNull(message = "Please provide email address")
	private String empEmail;

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	public Employee() {
	
	}

	public Employee(int empId, String empName, String empDesg, int empSalary, String empEmail) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDesg = empDesg;
		this.empSalary = empSalary;
		this.empEmail = empEmail;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empDesg=" + empDesg + ", empSalary=" + empSalary
				+ ", empEmail=" + empEmail + "]";
	}



}
