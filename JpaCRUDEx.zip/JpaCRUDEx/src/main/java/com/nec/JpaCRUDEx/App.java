package com.nec.JpaCRUDEx;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("NEC");

		EntityManager entityManager = factory.createEntityManager();

		//Product product = new Product(1112, "laptop", 22300, "samsung");
		entityManager.getTransaction().begin();
	//	entityManager.persist(product);
		Product product1=entityManager.find(Product.class, 1111);
		System.out.println(product1);
		product1.setProductPrice(29000);
		entityManager.merge(product1);
		entityManager.remove(product1);
		entityManager.getTransaction().commit();

	}
}
