package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

//{
//"empId":124,
//"empName":"sandeep",
//"empDesg":"trainer",
//"empSalary":"60000"
//}
@RestController // @Controller+@ResponseBody
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	EmployeeService service;

	@PostMapping("/createEmployee") // http://localhost:1234/employee/createEmployee
	public String addEmployee(@RequestBody Employee emp) {

		return service.addEmployee(emp);
	}
	@PutMapping("/updateEmployee") // http://localhost:1234/employee/updateEmployee
	public Employee updateEmployee(@RequestBody Employee emp) {

		return service.updateEmployee(emp);
	}
	@DeleteMapping("/deleteEmployee/{id}") // http://localhost:1234/employee/deleteEmployee/123
	public String deleteEmployee(@PathVariable("id") int  empid) {

		return service.deleteEmployee(empid);
	}
	@GetMapping("/getEmployee/{id}") // http://localhost:1234/employee/getEmployee/123
	public Employee getEmployee(@PathVariable("id") int  empid) {

		return service.getEmployee(empid);
	}
	@GetMapping("/getEmployees") // http://localhost:1234/employee/getEmployees
	public List<Employee> getAllEmployees() {

		return service.getAllEmployees();
	}
	@GetMapping("/getAllEmployeeInBetween/{intialSal}/{finalSal}") // http://localhost:1234/employee/getAllEmployeeInBetween/1000/2000
	public List<Employee> getEmployeeInBetween(@PathVariable("intialSal") int  sal1,@PathVariable("finalSal")int sal2) {

		return service.getEmployeesInBetweenSalary(sal1, sal2);
	}
	@GetMapping("/getAllEmployeesByName/{name}") // http://localhost:1234/employee/getAllEmployeesByName/sandeep
	public List<Employee> getEmployeesByName(@PathVariable String name) {

		return service.getEmployeesByName(name);
	}
	@GetMapping("/getAllEmployeesByDesg/{desg}") // http://localhost:1234/employee/getAllEmployeesByDesg/trainer
	public List<Employee> getEmployeesByDisg(@PathVariable String desg) {

		return service.getEmployeesByDesg(desg);
	}
}
