package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepo;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepo repo;

	@Override
	public String addEmployee(Employee employee) {
		repo.save(employee);
		return "Employee Inserted....";
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		return repo.save(employee);
	}

	@Override
	public String deleteEmployee(int employeeId) {
		repo.deleteById(employeeId);
		return "Employee Removed...";
	}

	@Override
	public Employee getEmployee(int employeeId) {
	Optional<Employee> obj=	repo.findById(employeeId);
		return obj.get();
	}

	@Override
	public List<Employee> getAllEmployees() {

		return repo.findAll();
	}
//https://stackabuse.com/guide-to-spring-data-jpa/
	@Override
	public List<Employee> getEmployeesInBetweenSalary(int intialSal, int finalSal) {

		return repo.findByEmpSalaryBetween(intialSal, finalSal);
	}

	@Override
	public List<Employee> getEmployeesByName(String employeeName) {
		return repo.findByEmpName(employeeName);
	}

	@Override
	public List<Employee> getEmployeesByDesg(String employeeDesg) {
		return repo.findByEmpDesg(employeeDesg);
	}

}
