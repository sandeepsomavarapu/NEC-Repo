package com.example.demo.exception;

public class EmployeeIdNotFound extends Exception {
	public EmployeeIdNotFound(String message) {
		super(message);
	}
}
